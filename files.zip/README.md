# ⚡ Business Command Center

AI-Powered Financial & Email Dashboard — Mobile PWA

## Features
- **Dashboard** — Real-time KPIs (Gross/Net Revenue, Expenses, Profit Margin)
- **Finanças** — Full income/expense tracking with categories
- **Email Hub** — Gmail integration with AI-powered email scanner
- **AI Agent** — Financial assistant with real-time company data
- **Reports** — Daily reports with TXT/CSV export and Gmail draft

## Install on Phone
1. Open the link in Safari (iPhone) or Chrome (Android)
2. **iPhone**: Tap Share → "Add to Home Screen"
3. **Android**: Tap ⋮ menu → "Install app"

## Update
Just edit `index.html` on GitHub — the app auto-updates on next open.
